newWin1 = new yglloWindow("hello", 150, 100, 100, 100);
document.body.append(newWin1);

newWin2 = new yglloWindow("world", 100, 200, 400, 400);
document.body.append(newWin2);
