# yglloWM
 a modern lightwheight window manager for web browser 
