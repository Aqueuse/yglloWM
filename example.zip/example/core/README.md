# yglloWM

A modern lightwheight window manager for web browser, inspired by YGWM, made by Aqueuse. Ergonomy and code readability enhanced.
